# English-Urdu Dictionary with Audio Pronunciation

## Description
This Python program allows you to look up English words and see their Urdu meanings.  
It also pronounces the English word and its Urdu meaning aloud using Google's Text-to-Speech (gTTS).

## Features
- Reads English-Urdu word pairs from `dictionary.txt`.
- Case-insensitive search for English words.
- Speaks both English words and Urdu meanings.
- Keeps running until the user types `exit`.
- Handles errors like missing dictionary file or internet issues.

## Setup Instructions
1. Make sure Python is installed on your system.
2. Install required packages:

## pip install gtts playsound
- Place `urdu_dictionary.py` and `dictionary.txt` in the same folder.
- Run the program:

## python urdu_dictionary1.py

- 
## File Structure

English-Urdu-Dictionary/
│
├── urdu_dictionary.py # Main program
├── dictionary.txt # English-Urdu word list
└── README.md # This file


## Sample Entries in dictionary1.txt`

- apple:سیب
- book:کتاب
- computer:کمپیوٹر
- teacher:استاد
- school:سکول
- water:پانی
- friend:دوست
- house:گھر
- city:شہر
- love:محبت



## Notes
- Requires internet connection for text-to-speech.
- Urdu words must be saved in UTF-8 encoding.
- If audio doesn’t play, try installing `playsound` version 1.2.2:

## pip install playsound==1.2.2
Enjoy using your English-Urdu Dictionary!  
Feel free to add more words to `dictionary.txt`.

